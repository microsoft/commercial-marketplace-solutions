# azure-managed-terraform
This is just a prototype for terraform with azure-managed 
1. This is free code as it is
1. this code will deploy a simple storage account
1. this code demos how to use terraform to deploy resources and how to pass variables to the script.
